package CT;
import databaseconnection.*;
import java.sql.*;

public class  Details
{

static Connection con1=null;
static Statement st1=null;

static String[] res=new String[3];


public static String[] main(String qid) {
try{


con1 = databasecon.getconnection();
st1 = con1.createStatement();
 String sql=null;;
sql="select * from query where qid='"+qid+"' ";
System.out.println(sql);
ResultSet rs=null;
rs=st1.executeQuery(sql);

while(rs.next())
{
//System.out.println(rs.getString("user"));
	res[0]=rs.getString(2);
		res[1]=rs.getString(3);
			res[2]=rs.getString(4);
	}
}
	catch(Exception e){
		System.out.println(e);
	}
	finally{
		try{
		con1.close();
		st1.close();
//		rs.close();
		}
		catch(Exception e){
		System.out.println(e);
		}
	}
	return res;
}



	public static void main(String[] args) 
	{
		
String[] r=Details.main("1");
for(String rr:r)
		{
System.out.println(rr);
}



	}

}



